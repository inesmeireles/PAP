##### 1.0.1 - 2017-04-04
###### examples
- fix: ConnectNoEncryption check status removed
- upd: notes were updated (descriptions, typos, etc...)
- upd: baudarate increased
- add: Tools/EspRecovery example
- upd: CheckFirmwareVersion example based on new API
- fix: WiFiRestServer better request management, http status code

###### library
- fix: compatibility with uno wifi dev. ed.
- add: checkFirmwareVersion API

##### 1.0.0 - 2017-03-13
- First release
